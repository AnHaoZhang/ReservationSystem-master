create trigger administrator_BEFORE_UPDATE
  before UPDATE
  on administrator
  for each row
BEGIN
if (new.arole != 1) then  
		set new.arole = 1;
    end if;
END;

